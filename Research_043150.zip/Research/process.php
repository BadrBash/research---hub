<?php
/*======== 1. DB CONNECTION ========*/
include 'conn.php';

/*======== 2. STUDENT SIGNIN ========*/
if ($_POST['ptype'] == 'StudentLog') {
	$matric = $_POST['matric'];
	$password = $_POST['password'];
	$pass = md5($password);
	$sql = "SELECT * FROM students WHERE matric = '$matric' and password = '$pass'";
	$query = mysqli_query($conn, $sql);
	if (mysqli_num_rows($query) > 0) {
	    while ($row = mysqli_fetch_assoc($query)) {
		    $id = $row['id'];
		    session_start();
		    $_SESSION['StudentLog'] = $matric;
		    echo 'success';
		}
	} else {
		echo 'failed';
	}
}

/*======== 3. STUDENT SIGNOUT ========*/
if ($_POST['ptype'] == 'slogout') {
	session_start();
	unset($_SESSION["StudentLog"]);
}



/*======== 4. ADMIN SIGNIN ========*/
if ($_POST['ptype'] == 'AdminLog') {
	$email = $_POST['email'];
	$password = $_POST['password'];
	$pass = md5($password);
	$sql = "SELECT * FROM admin WHERE email = '$email' and password = '$pass'";
	$query = mysqli_query($conn, $sql);
	if (mysqli_num_rows($query) > 0) {
	    while ($row = mysqli_fetch_assoc($query)) {
		    $id = $row['id'];
		    session_start();
		    $_SESSION['AdminLog'] = $email;
		    echo 'success';
		}
	} else {
		echo 'failed';
	}
}

/*======== 5. ADMIN SIGNOUT ========*/
if ($_POST['ptype'] == 'alogout') {
	session_start();
	unset($_SESSION["AdminLog"]);
}





/*======== 6. STUDENT ADD CHECHK EMAIL ========*/
if ($_POST['ptype'] == 'checkerID') {
	$matric = $_POST['matric'];
	$sql = "SELECT * FROM students WHERE matric = '$matric'";
	$query = mysqli_query($conn, $sql);
	if (mysqli_num_rows($query) > 0) {
		echo "<script>
				$('#StudentAdd #matric').removeClass('is-valid');
				$('#StudentAdd #matric').addClass('is-invalid');
				$('#StudentAdd #matric-error').html('Matric Not Avaliable!');
				$('#StudentAdd #matric-error').removeClass('text-success');
				$('#StudentAdd #matric-error').addClass('text-danger');
			    $('#StudentAdd #submit').attr('disabled', true);
			    $('#StudentAdd #submit').addClass('btn-danger');
			    $('#StudentAdd #submit').removeClass('btn-primary');
			 </script>";
	} else {
		echo "<script>
				$('#StudentAdd #matric-error').html('Matric Is Avaliable For Registration!');
				$('#StudentAdd #matric-error').removeClass('text-danger');
				$('#StudentAdd #matric-error').addClass('text-success');
				$('#StudentAdd #matric').removeClass('is-invalid');
				$('#StudentAdd #matric').addClass('is-valid');
			 </script>";
	}
}





/*======== 8. Student ADD ========*/
if ($_POST['ptype'] == 'StudentAdd') {
	$matric = $_POST['matric'];
	$sql = "INSERT INTO students (matric) VALUES ('$matric')";
	$query = mysqli_query($conn, $sql);
	if ($query) {
		echo 'success';
	} else {
		echo 'failed';
	}	
}



/*======== 14. REGISTERED DELETE ========*/
if ($_POST['ptype'] == 'RSDelete') {
	$id = $_POST['id'];
	foreach ($_POST['id'] as $id) {
	$sql = "UPDATE students SET delete_flag = 1 WHERE id = '$id'";
	$query = mysqli_query($conn, $sql);
		if ($query) {
			echo 'success';
		} else {
			echo 'failed';
		}	
	}
}


/*======== 14. UNREGISTERED DELETE ========*/
if ($_POST['ptype'] == 'URSDelete') {
	$id = $_POST['id'];
	foreach ($_POST['id'] as $id) {
	$sql = "UPDATE students SET delete_flag = 1 WHERE id = '$id'";
	$query = mysqli_query($conn, $sql);
		if ($query) {
			echo 'success';
		} else {
			echo 'failed';
		}	
	}
}




/*======== 6. STUDENT ADD CHECHK EMAIL ========*/
if ($_POST['ptype'] == 'checkerDpt') {
	$dname = $_POST['dname'];
	$sql = "SELECT * FROM departments WHERE dname = '$dname'";
	$query = mysqli_query($conn, $sql);
	if (mysqli_num_rows($query) > 0) {
		echo "<script>
				$('#StudentAdd #dname').removeClass('is-valid');
				$('#StudentAdd #dname').addClass('is-invalid');
				$('#StudentAdd #dname-error').html('Department Already Avaliable!');
				$('#StudentAdd #dname-error').removeClass('text-success');
				$('#StudentAdd #dname-error').addClass('text-danger');
			    $('#StudentAdd #submit').attr('disabled', true);
			    $('#StudentAdd #submit').addClass('btn-danger');
			    $('#StudentAdd #submit').removeClass('btn-primary');
			 </script>";
	} else {
		echo "<script>
				$('#StudentAdd #dname-error').html('Department Is Avaliable For Registration!');
				$('#StudentAdd #dname-error').removeClass('text-danger');
				$('#StudentAdd #dname-error').addClass('text-success');
				$('#StudentAdd #dname').removeClass('is-invalid');
				$('#StudentAdd #dname').addClass('is-valid');
			 </script>";
	}
}




/*======== 8. Student ADD ========*/
if ($_POST['ptype'] == 'DepartmentAdd') {
	$dname = $_POST['dname'];
	$dshort = $_POST['dshort'];
	$sql = "INSERT INTO departments (dname, dshort) VALUES ('$dname', '$dshort' )";
	$query = mysqli_query($conn, $sql);
	if ($query) {
		echo 'success';
	} else {
		echo 'failed';
	}	
}



/*======== 14. REGISTERED DELETE ========*/
if ($_POST['ptype'] == 'DeptDelete') {
	$id = $_POST['id'];
	foreach ($_POST['id'] as $id) {
	$sql = "UPDATE departments SET delete_flag = 1 WHERE id = '$id'";
	$query = mysqli_query($conn, $sql);
		if ($query) {
			echo 'success';
		} else {
			echo 'failed';
		}	
	}
}




/*======== 8. lecturer ADD ========*/
if ($_POST['ptype'] == 'LecturerAdd') {
	$fullname = $_POST['fullname'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];
	$email = $_POST['email'];
	$department = $_POST['department'];
	$password = $_POST['password'];
	$pass = md5($password);
	$sql = "INSERT INTO lecturers (fullname, phone, address, email, department, password) VALUES ('$fullname', '$phone', '$address', '$email', '$department', '$pass' )";
	$query = mysqli_query($conn, $sql);
	if ($query) {
		echo 'success';
	} else {
		echo 'failed';
	}	
}



/*======== 14. lecturer DELETE ========*/
if ($_POST['ptype'] == 'LectDelete') {
	$id = $_POST['id'];
	foreach ($_POST['id'] as $id) {
	$sql = "UPDATE lecturers SET delete_flag = 1 WHERE id = '$id'";
	$query = mysqli_query($conn, $sql);
		if ($query) {
			echo 'success';
		} else {
			echo 'failed';
		}	
	}
}



/*======== 2. Lecturer SIGNIN ========*/
if ($_POST['ptype'] == 'LecturerLog') {
	$email = $_POST['email'];
	$password = $_POST['password'];
	$pass = md5($password);
	$sql = "SELECT * FROM lecturers WHERE email = '$email' and password = '$pass'";
	$query = mysqli_query($conn, $sql);
	if (mysqli_num_rows($query) > 0) {
	    while ($row = mysqli_fetch_assoc($query)) {
		    $id = $row['id'];
		    session_start();
		    $_SESSION['LecturerLog'] = $email;
		    echo 'success';
		}
	} else {
		echo 'failed';
	}
}

/*======== 3. Lecturer SIGNOUT ========*/
if ($_POST['ptype'] == 'slogout') {
	session_start();
	unset($_SESSION["LecturerLog"]);
}


// Uploads files
if ($_POST['ptype'] == 'ProjectAdd') {

    $uploader = $_POST['matric'];
    $supervisor = $_POST['lecturer'];
    $department = $_POST['department'];
    $topic = $_POST['topic'];

    $filename = $_FILES['myfile']['name'];

    $destination = 'uploads/' . $filename;

    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);
    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO projects (filename, filesize, download, uploader, supervisor, department, topic) VALUES ('$filename', $size , 0, '$uploader', '$supervisor', '$department', '$topic')";
            if (mysqli_query($conn, $sql)) {
                echo 'success';
            } else {
            	echo 'failed';
            }
        } else {
             echo "failed";
        }
    
  }



/*======== 15.  ProjectID GET ========*/
if ($_POST['ptype'] == 'ProjectID') {
	$id = $_POST['id'];
	$sql = "SELECT * FROM projects WHERE id='$id'";
	$results = $conn->query($sql);
	$row = $results->fetch_assoc();
	$results->free_result();
	$conn->close();
	echo json_encode($row);
}




/*======== 8. Update comment ========*/
if ($_POST['ptype'] == 'MakeComment') {
	$id = $_POST['id'];
	$remark = $_POST['remark'];
	$sql = "UPDATE projects SET remark = '$remark', status = 2 WHERE id = '$id'";
	$query = mysqli_query($conn, $sql);
	if ($query) {
		echo 'success';
	} else {
		echo 'failed';
	}	
}


// Uploads Notes
if ($_POST['ptype'] == 'NoteAdd') {

    $uploader = $_POST['fullname'];
    $department = $_POST['department'];
    $level = $_POST['level'];
    $topic = $_POST['topic'];

    $filename = $_FILES['myfile']['name'];

    $destination = 'uploads/' . $filename;

    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);
    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO notes (filename, filesize, download, uploader, department, topic, level) VALUES ('$filename', $size , 0, '$uploader', '$department', '$topic', '$level')";
            if (mysqli_query($conn, $sql)) {
                echo 'success';
            } else {
            	echo 'failed';
            }
        } else {
             echo "failed";
        }
    
  }




/*======== 14. REGISTERED DELETE ========*/
if ($_POST['ptype'] == 'NoteDelete') {
	$id = $_POST['id'];
	foreach ($_POST['id'] as $id) {
	$sql = "UPDATE notes SET delete_flag = 1 WHERE id = '$id'";
	$query = mysqli_query($conn, $sql);
		if ($query) {
			echo 'success';
		} else {
			echo 'failed';
		}	
	}
}



/*======== 14. REGISTERED DELETE ========*/
if ($_POST['ptype'] == 'ProDelete') {
	$id = $_POST['id'];
	foreach ($_POST['id'] as $id) {
	$sql = "UPDATE projects SET delete_flag = 1 WHERE id = '$id'";
	$query = mysqli_query($conn, $sql);
		if ($query) {
			echo 'success';
		} else {
			echo 'failed';
		}	
	}
}





/*======== 6. STUDENT ADD CHECHK EMAIL ========*/
if ($_POST['ptype'] == 'checkerID2') {
	$matric = $_POST['matric'];
	$sql = "SELECT * FROM students WHERE matric = '$matric' and status = 0";
	$query = mysqli_query($conn, $sql);
	if (mysqli_num_rows($query) > 0) {
		echo "<script>
				$('#sregister #matric-error').html('Matric Is Avaliable For Registration!');
				$('#sregister #matric-error').removeClass('text-danger');
				$('#sregister #matric-error').addClass('text-success');
				$('#sregister #matric').removeClass('is-invalid');
				$('#sregister #matric').addClass('is-valid');
	 		</script>";
	} else {
		echo "<script>
			$('#sregister #matric').removeClass('is-valid');
				$('#sregister #matric').addClass('is-invalid');
				$('#sregister #matric-error').html('Matric Not Avaliable!');
				$('#sregister #matric-error').removeClass('text-success');
				$('#sregister #matric-error').addClass('text-danger');
			    $('#sregister #submit').attr('disabled', true);
			    $('#sregister #submit').addClass('btn-danger');
			    $('#sregister #submit').removeClass('btn-primary');
			 </script>";
	}
}




/*======== 8. Student reg comment ========*/
if ($_POST['ptype'] == 'StudentReg') {
	$fullname = $_POST['fullname'];
	$matric = $_POST['matric'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$department = $_POST['department'];
	$password = $_POST['password'];
	$pass = md5($password);
	$sql = "UPDATE students SET fullname = '$fullname', email = '$email', fullname = '$fullname', phone = '$phone', password = '$pass', department = '$department', status = 1 WHERE matric = '$matric'";
	$query = mysqli_query($conn, $sql);
	if ($query) {
		echo 'success';
	} else {
		echo 'failed';
	}	
}


?>