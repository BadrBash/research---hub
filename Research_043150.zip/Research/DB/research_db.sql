-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2023 at 12:57 AM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `research_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `indate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullname`, `email`, `password`, `indate`) VALUES
(1, 'Kelvin Payne', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2023-10-17 12:01:33');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE IF NOT EXISTS `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dname` varchar(50) DEFAULT NULL,
  `dshort` varchar(50) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `delete_flag` int(1) NOT NULL DEFAULT '0',
  `indate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `dname`, `dshort`, `status`, `delete_flag`, `indate`) VALUES
(1, 'gfdsgfd', 'dfsgsdfg', 1, 0, '2023-10-30 21:24:31'),
(2, 'fdsaf', 'dsafas', 1, 0, '2023-10-30 21:48:26');

-- --------------------------------------------------------

--
-- Table structure for table `lecturers`
--

DROP TABLE IF EXISTS `lecturers`;
CREATE TABLE IF NOT EXISTS `lecturers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `delete_flag` int(1) NOT NULL DEFAULT '0',
  `indate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturers`
--

INSERT INTO `lecturers` (`id`, `email`, `fullname`, `phone`, `department`, `address`, `password`, `status`, `delete_flag`, `indate`) VALUES
(1, 'jc@gmail.com', 'John Carter', 'dfsgd', 'fdsaf', 'fdgfds', 'e10adc3949ba59abbe56e057f20f883e', 1, 0, '2023-10-30 21:56:20');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) DEFAULT NULL,
  `filename` varchar(50) NOT NULL,
  `filesize` varchar(50) NOT NULL,
  `uploader` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `download` varchar(50) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `delete_flag` int(1) NOT NULL DEFAULT '0',
  `indate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `topic`, `filename`, `filesize`, `uploader`, `level`, `department`, `download`, `status`, `delete_flag`, `indate`) VALUES
(1, 'hgfhdg', 'file_management.sql', '5879', '', 'All', 'All', '0', 1, 1, '2023-10-30 23:56:41'),
(2, 'hdhf', 'file_management.sql', '5879', 'John Carter', 'ND 1', 'All', '0', 1, 0, '2023-10-30 23:57:54');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(100) DEFAULT NULL,
  `filename` varchar(50) DEFAULT NULL,
  `filesize` varchar(50) DEFAULT NULL,
  `uploader` varchar(50) DEFAULT NULL,
  `supervisor` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `remark` text,
  `download` varchar(50) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `delete_flag` int(1) NOT NULL DEFAULT '0',
  `indate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `topic`, `filename`, `filesize`, `uploader`, `supervisor`, `department`, `remark`, `download`, `status`, `delete_flag`, `indate`) VALUES
(1, NULL, 'file_management.sql', '5879', '1234', 'jc@gmail.com', 'fdsaf', 'dfghfdhfghddfg', '2', 2, 1, '2023-10-30 22:48:06'),
(2, NULL, 'file_management.sql', '5879', '1234', 'jc@gmail.com', 'fdsaf', 'gfdsgfsgdsfgdfsg', '1', 2, 0, '2023-10-30 22:48:50'),
(3, 'hdfhggd', 'file_management.sql', '5879', '1234', 'jc@gmail.com', 'fdsaf', NULL, '0', 1, 0, '2023-10-31 00:13:59');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matric` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `delete_flag` int(1) NOT NULL DEFAULT '0',
  `indate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `matric`, `email`, `fullname`, `phone`, `department`, `password`, `status`, `delete_flag`, `indate`) VALUES
(1, '1234', NULL, NULL, NULL, NULL, 'e10adc3949ba59abbe56e057f20f883e', 1, 0, '2023-10-30 20:29:13'),
(2, 'sdfg', NULL, NULL, NULL, NULL, NULL, 0, 1, '2023-10-30 20:32:01'),
(3, 'sdafds', NULL, NULL, NULL, NULL, NULL, 1, 0, '2023-10-30 20:32:34'),
(4, 'fdghd', NULL, NULL, NULL, NULL, NULL, 0, 1, '2023-10-30 20:33:23'),
(5, '123456', 'jc@gmail.com', 'hfghfghd ', 'fdsgsdfg', 'gfdsgfd', '610623ef42c38bee360631f9a68eab17', 1, 0, '2023-10-30 20:33:35');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
