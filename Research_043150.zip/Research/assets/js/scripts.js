// ======================================================================================
// ======================================================================================
// ======================================================================================
// ======================================================================================

// ======================================================================================
//  Student Sign In Validation Function
// ======================================================================================
function slogin() {
    var valid = true;
    valid = checke2($('#slogin #matric'));
    valid = valid && checke2($('#slogin #password'));
    $('#slogin #submit').attr('disabled', true);
    $('#slogin #submit').addClass('btn-danger');
    $('#slogin #submit').removeClass('btn-primary');
    if (valid) {
      $('#slogin #submit').attr('disabled', false);
      $('#slogin #submit').removeClass('btn-danger');
      $('#slogin #submit').addClass('btn-primary');
    }
  }



// ======================================================================================
//  Student Sign In Validation Function
// ======================================================================================
function alogin() {
    var valid = true;
    valid = checkeEmail($('#alogin #email'));
    valid = valid && checke2($('#alogin #password'));
    $('#alogin #submit').attr('disabled', true);
    $('#alogin #submit').addClass('btn-danger');
    $('#alogin #submit').removeClass('btn-primary');
    if (valid) {
      $('#alogin #submit').attr('disabled', false);
      $('#alogin #submit').removeClass('btn-danger');
      $('#alogin #submit').addClass('btn-primary');
    }
  }


// ======================================================================================
//  Student Sign In Function
// ======================================================================================
function llogin() {
    var valid = true;
    valid = checkeEmail($('#llogin #email'));
    valid = valid && checke2($('#llogin #password'));
    $('#llogin #submit').attr('disabled', true);
    $('#llogin #submit').addClass('btn-danger');
    $('#llogin #submit').removeClass('btn-primary');
    if (valid) {
      $('#llogin #submit').attr('disabled', false);
      $('#llogin #submit').removeClass('btn-danger');
      $('#llogin #submit').addClass('btn-primary');
    }
  }

function checke2(obj) {
  var value = obj.val();
  var name = obj.attr('id');
  if (value == '') {
    $('#'+name).addClass('is-invalid');
    $('#'+name).removeClass('is-valid');
    return false;
  } else {
    $('#'+name).addClass('is-valid');
    $('#'+name).removeClass('is-invalid');
  }
  return true;  
}

function checkeEmail(obj) {
  var value = obj.val();
  var name = obj.attr('name');
  if (value == '') {
    $('#'+name).addClass('is-invalid');
    $('#'+name).removeClass('is-valid');
    $('#'+name+'-error').html('');
    return false;
  } else {
    var email_regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,3})+$/;
        result = email_regex.test(value);
        if (!result) {
            $('#'+name).addClass('is-invalid');
            $('#'+name).removeClass('is-valid');
            $('#email-error').html('Invalid Email Address!');
            $('#email-error').addClass('text-danger');
            return false;
        } else {
            $('#'+name+'-error').html('');
            $('#'+name).addClass('is-valid');
            $('#'+name).removeClass('is-invalid');
        }
  }
  return true;  
}



// ======================================================================================
//  Student Sign In Function
// ======================================================================================
$('#slogin #submit').on('click', function () {
    var btn = $(this);
    var btnText = btn.html();
    var route = 'process.php';
    var formData = $('#slogin').serialize()
    // the ajax save function 
    $.ajax({
        url: route,
        type: 'post',
        data: formData,
        // function to run before submit
        beforeSend: function () {
            btn.attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Authentication Successful!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='student';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Email or Password Not Correct!',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='slogin.php';
              })
          }
        }
    })
})


// ======================================================================================
//  Admin Sign In Function
// ======================================================================================
$('#alogin #submit').on('click', function () {
    var btn = $(this);
    var btnText = btn.html();
    var route = 'process.php';
    var formData = $('#alogin').serialize()
    // the ajax save function 
    $.ajax({
        url: route,
        type: 'post',
        data: formData,
        // function to run before submit
        beforeSend: function () {
            btn.attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Authentication Successful!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='admin';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Email or Password Not Correct!',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='alogin.php';
              })
          }
        }
    })
})



// ======================================================================================
//  Admin Check Student Function
// ======================================================================================
function StudentAdd() {
    var valid = true;
    valid = checkerID($('#StudentAdd #matric'));
    $('#StudentAdd #submit').attr('disabled', true);
    $('#StudentAdd #submit').addClass('btn-danger');
    $('#StudentAdd #submit').removeClass('btn-primary');
    if (valid) {
      $('#StudentAdd #submit').attr('disabled', false);
      $('#StudentAdd #submit').removeClass('btn-danger');
      $('#StudentAdd #submit').addClass('btn-primary');
    }
  }

function checkerID(obj) {
  var value = obj.val();
  var name = obj.attr('id');
  $('#'+name+'-error').html('');
  if (value == '') {
    $('#'+name).addClass('is-invalid');
    $('#'+name).removeClass('is-valid');
    return false;
  } else {
    $.ajax({
      url: '../process.php',
      type: 'post',
      data: {ptype:'checkerID', matric:value},
      success: function (data) {
        $('#'+name+'-error').html(data);
      }
    })
  }
  return true;  
}



// ======================================================================================
//  Admin Sign In Function
// ======================================================================================
$('#StudentAdd #submit').on('click', function () {
    var btn = $(this);
    var btnText = btn.html();
    var route = '../process.php';
    var formData = $('#StudentAdd').serialize()
    // the ajax save function 
    $.ajax({
        url: route,
        type: 'post',
        data: formData,
        // function to run before submit
        beforeSend: function () {
            btn.attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Matric Added!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='student-add.php';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Failed To Add!',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='student-add.php';
              })
          }
        }
    })
})





// ======================================================================================
//  Admin Check Student Function
// ======================================================================================
function DepartmentAdd() {
    var valid = true;
    valid = checke2($('#DepartmentAdd #dname'));
    valid = valid && checke2($('#DepartmentAdd #dshort'));
    $('#DepartmentAdd #submit').attr('disabled', true);
    $('#DepartmentAdd #submit').addClass('btn-danger');
    $('#DepartmentAdd #submit').removeClass('btn-primary');
    if (valid) {
      $('#DepartmentAdd #submit').attr('disabled', false);
      $('#DepartmentAdd #submit').removeClass('btn-danger');
      $('#DepartmentAdd #submit').addClass('btn-primary');
    }
  }

function checkerDpt(obj) {
  var value = obj.val();
  var name = obj.attr('id');
  $('#'+name+'-error').html('');
  if (value == '') {
    $('#'+name).addClass('is-invalid');
    $('#'+name).removeClass('is-valid');
    return false;
  } else {
    $.ajax({
      url: '../process.php',
      type: 'post',
      data: {ptype:'checkerDpt', dname:value},
      success: function (data) {
        $('#'+name+'-error').html(data);
      }
    })
  }
  return true;  
}



// ======================================================================================
//  Department add Function
// ======================================================================================
$('#DepartmentAdd #submit').on('click', function () {
    var btn = $(this);
    var btnText = btn.html();
    var route = '../process.php';
    var formData = $('#DepartmentAdd').serialize()
    // the ajax save function 
    $.ajax({
        url: route,
        type: 'post',
        data: formData,
        // function to run before submit
        beforeSend: function () {
            btn.attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Department Added!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='department-add.php';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Failed To Add!',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='department-add.php';
              })
          }
        }
    })
})




// ======================================================================================
//  Lectuere Student Function
// ======================================================================================
function LecturerAdd() {
    var valid = true;
    valid = checke2($('#LecturerAdd #fullname'));
    valid = valid && checke2($('#LecturerAdd #email'));
    valid = valid && checke2($('#LecturerAdd #phone'));
    valid = valid && checke2($('#LecturerAdd #department'));
    valid = valid && checke2($('#LecturerAdd #address'));
    valid = valid && checke2($('#LecturerAdd #password'));
    $('#LecturerAdd #submit').attr('disabled', true);
    $('#LecturerAdd #submit').addClass('btn-danger');
    $('#LecturerAdd #submit').removeClass('btn-primary');
    if (valid) {
      $('#LecturerAdd #submit').attr('disabled', false);
      $('#LecturerAdd #submit').removeClass('btn-danger');
      $('#LecturerAdd #submit').addClass('btn-primary');
    }
  }

// ======================================================================================
//  Department add Function
// ======================================================================================
$('#LecturerAdd #submit').on('click', function () {
    var btn = $(this);
    var btnText = btn.html();
    var route = '../process.php';
    var formData = $('#LecturerAdd').serialize()
    // the ajax save function 
    $.ajax({
        url: route,
        type: 'post',
        data: formData,
        // function to run before submit
        beforeSend: function () {
            btn.attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Lecturer Added!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='lecturer-add.php';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Failed To Add!',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='lecturer-add.php';
              })
          }
        }
    })
})




// ======================================================================================
//  Lecturer In Function
// ======================================================================================
$('#llogin #submit').on('click', function () {
    var btn = $(this);
    var btnText = btn.html();
    var route = 'process.php';
    var formData = $('#llogin').serialize()
    // the ajax save function 
    $.ajax({
        url: route,
        type: 'post',
        data: formData,
        // function to run before submit
        beforeSend: function () {
            btn.attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Authentication Successful!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='lecturer';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Email or Password Not Correct!',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='llogin.php';
              })
          }
        }
    })
})



// ======================================================================================
//  Project Student Function
// ======================================================================================
function ProjectAdd() {
    var valid = true;
    valid = checke2($('#ProjectAdd #myfile'));
    valid = valid && checke2($('#ProjectAdd #topic'));
    valid = valid && checke2($('#ProjectAdd #lecturer'));
    valid = valid && checke2($('#ProjectAdd #department'));
    $('#ProjectAdd #submit').attr('disabled', true);
    $('#ProjectAdd #submit').addClass('btn-danger');
    $('#ProjectAdd #submit').removeClass('btn-primary');
    if (valid) {
      $('#ProjectAdd #submit').attr('disabled', false);
      $('#ProjectAdd #submit').removeClass('btn-danger');
      $('#ProjectAdd #submit').addClass('btn-primary');
    }
  }




// ======================================================================================
//  Project Student Function
// ======================================================================================
$("#ProjectAdd").on('submit', function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '../process.php',
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData:false,
        // the ajax save function 
        // function to run before submit
        beforeSend: function () {
            $('#ProjectAdd button').attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Project Submitted!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='project-add.php';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Error With Submission',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='project-add.php';
              })
          }
          
        }
    })
})





// ======================================================================================
//   Student Logout Function
// ======================================================================================
$('#slogout').on('click', function () {
  Swal.fire({
      icon: 'warning',
      title: 'Logout',
      text: 'Are you sure you want to logout?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: 'Yes, I Am',
      denyButtonText: 'No, Am Not',
      reverseButtons: true,
  }).then((result) => {
          if (result.isConfirmed) {
            $.ajax({
                type: "post", //we are using GET method to get data from server side
                url: '../process.php', // get the route value
                data: {ptype: 'slogout'}, //set data
                success: function (response) {//once the request successfully process to the server side it will return result here
                    // Reload lists of employees
                    Swal.fire({
                      title: 'Success.', 
                      text: 'Good Bye!', 
                      icon: 'success',
                      timer: 1000
                    }).then(function () {
                        // body...
                        window.location = '../slogin.php';
                    })
                }
            });
        } else if (result.isDenied) {
          Swal.fire({
            title: 'Canceled.', 
            text: 'Action Canceled!', 
            icon: 'error',
            timer: 1000
          })
        }
    });
})



// ======================================================================================
//   Admin Logout Function
// ======================================================================================
$('#alogout').on('click', function () {
  Swal.fire({
      icon: 'warning',
      title: 'Logout',
      text: 'Are you sure you want to logout?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: 'Yes, I Am',
      denyButtonText: 'No, Am Not',
      reverseButtons: true,
  }).then((result) => {
          if (result.isConfirmed) {
            $.ajax({
                type: "post", //we are using GET method to get data from server side
                url: '../process.php', // get the route value
                data: {ptype: 'alogout'}, //set data
                success: function (response) {//once the request successfully process to the server side it will return result here
                    // Reload lists of employees
                    Swal.fire({
                      title: 'Success.', 
                      text: 'Good Bye!', 
                      icon: 'success',
                      timer: 1000
                    }).then(function () {
                        // body...
                        window.location = '../alogin.php';
                    })
                }
            });
        } else if (result.isDenied) {
          Swal.fire({
            title: 'Canceled.', 
            text: 'Action Canceled!', 
            icon: 'error',
            timer: 1000
          })
        }
    });
})


// ======================================================================================
//   Admin Logout Function
// ======================================================================================
$('#llogout').on('click', function () {
  Swal.fire({
      icon: 'warning',
      title: 'Logout',
      text: 'Are you sure you want to logout?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: 'Yes, I Am',
      denyButtonText: 'No, Am Not',
      reverseButtons: true,
  }).then((result) => {
          if (result.isConfirmed) {
            $.ajax({
                type: "post", //we are using GET method to get data from server side
                url: '../process.php', // get the route value
                data: {ptype: 'llogout'}, //set data
                success: function (response) {//once the request successfully process to the server side it will return result here
                    // Reload lists of employees
                    Swal.fire({
                      title: 'Success.', 
                      text: 'Good Bye!', 
                      icon: 'success',
                      timer: 1000
                    }).then(function () {
                        // body...
                        window.location = '../llogin.php';
                    })
                }
            });
        } else if (result.isDenied) {
          Swal.fire({
            title: 'Canceled.', 
            text: 'Action Canceled!', 
            icon: 'error',
            timer: 1000
          })
        }
    });
})



// ======================================================================================
//  MakeComment Function
// ======================================================================================
function MakeComment() {
    var valid = true;
    valid = checke2($('#MakeComment #remark'));
    $('#MakeComment #submit').attr('disabled', true);
    $('#MakeComment #submit').addClass('btn-danger');
    $('#MakeComment #submit').removeClass('btn-primary');
    if (valid) {
      $('#MakeComment #submit').attr('disabled', false);
      $('#MakeComment #submit').removeClass('btn-danger');
      $('#MakeComment #submit').addClass('btn-primary');
    }
  }
  

// ======================================================================================
//  Make Comment In Function
// ======================================================================================
$('#MakeComment #submit').on('click', function () {
    var btn = $(this);
    var btnText = btn.html();
    var route = '../process.php';
    var remark = $('#MakeComment #remark').val();
    var id = $('#MakeComment #id').val();
    // the ajax save function 
    $.ajax({
        url: route,
        type: 'post',
        data: {id:id, remark:remark, ptype:'MakeComment'},
        // function to run before submit
        beforeSend: function () {
            btn.attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Successful!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='project-new.php';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Failed!',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='project-new.php';
              })
          }
        }
    })
})



// ======================================================================================
//  Project Student Function
// ======================================================================================
function NoteAdd() {
    var valid = true;
    valid = checke2($('#NoteAdd #myfile'));
    valid = valid && checke2($('#NoteAdd #topic'));
    valid = valid && checke2($('#NoteAdd #lecturer'));
    valid = valid && checke2($('#NoteAdd #department'));
    $('#NoteAdd #submit').attr('disabled', true);
    $('#NoteAdd #submit').addClass('btn-danger');
    $('#NoteAdd #submit').removeClass('btn-primary');
    if (valid) {
      $('#NoteAdd #submit').attr('disabled', false);
      $('#NoteAdd #submit').removeClass('btn-danger');
      $('#NoteAdd #submit').addClass('btn-primary');
    }
  }




// ======================================================================================
//  Project Student Function
// ======================================================================================
$("#NoteAdd").on('submit', function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '../process.php',
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData:false,
        // the ajax save function 
        // function to run before submit
        beforeSend: function () {
            $('#NoteAdd button').attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Note Added!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='notes-add.php';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Error With Submission',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='notes-add.php';
              })
          }
          
        }
    })
})


// ======================================================================================
//  Student Sign Up Validation Function
// ======================================================================================
function sregister() {
    var valid = true;
    valid = checkerID2($('#sregister #matric'));
    valid = valid && checkeEmail($('#sregister #email'));
    valid = valid && checke2($('#sregister #fullname'));
    valid = valid && checke2($('#sregister #phone'));
    valid = valid && checke2($('#sregister #department'));
    valid = valid && checke2($('#sregister #password'));
    $('#sregister #submit').attr('disabled', true);
    $('#sregister #submit').addClass('btn-danger');
    $('#sregister #submit').removeClass('btn-primary');
    if (valid) {
      $('#sregister #submit').attr('disabled', false);
      $('#sregister #submit').removeClass('btn-danger');
      $('#sregister #submit').addClass('btn-primary');
    }
  }



function checkerID2(obj) {
  var value = obj.val();
  var name = obj.attr('id');
  $('#'+name+'-error').html('');
  if (value == '') {
    $('#'+name).addClass('is-invalid');
    $('#'+name).removeClass('is-valid');
    return false;
  } else {
    $.ajax({
      url: 'process.php',
      type: 'post',
      data: {ptype:'checkerID2', matric:value},
      success: function (data) {
        $('#'+name+'-error').html(data);
      }
    })
  }
  return true;  
}



// ======================================================================================
//  Admin Sign In Function
// ======================================================================================
$('#sregister #submit').on('click', function () {
    var btn = $(this);
    var btnText = btn.html();
    var route = 'process.php';
    var formData = $('#sregister').serialize()
    // the ajax save function 
    $.ajax({
        url: route,
        type: 'post',
        data: formData,
        // function to run before submit
        beforeSend: function () {
            btn.attr('disabled', true).html('Processing....')
        },
        success: function (data) { 
          if (data == 'success') {
            Swal.fire({
              title: 'Success', 
              text: 'Registration Successful!',
              icon: 'success',
              timer: 1500
              }).then(function () {
                window.location='slogin.php';
              })
          }
          if (data == 'failed') {
            Swal.fire({
              title: 'Error', 
              text: 'Failed To Register!',
              icon: 'error',
              timer: 1500
              }).then(function () {
                window.location='register.php';
              })
          }
        }
    })
})



