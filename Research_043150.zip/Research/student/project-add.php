<!DOCTYPE html>
<html lang="en">
<?php
include 'header.php';
?>
    
<body>

    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

<?php
include 'topnav.php';
?>

    <!-- Contact Start -->
    <div class="container-xxl pb-5 mt-5">
        <div class="container mb-5">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Student: <?php echo $matric; ?></h6>
            </div>
            <div class="mt-3">
                <div class="text-center">
                    <h5 class="">Submit Project</h5>
                </div>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <div class="container">
                <div class="row g-4 justify-content-center">
                    <div class="col-lg-6 col-md-12 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="card mt-3">
                            <div class="card-body text-center shadow-sm">
                                <form id="ProjectAdd" method="post" action="" enctype="multipart/form-data">
                                    <input type="hidden" name="ptype" value="ProjectAdd" readonly>
                                    <input type="hidden" name="matric" value="<?php echo $matric; ?>" readonly>
                                    <div class="row g-3">
                                        <div class="col-md-12">
                                            <div class="form-floating">
                                                <input type="file" class="form-control" name="myfile" id="myfile" placeholder="File" oninput="ProjectAdd()">
                                                <label for="name">File</label>
                                            </div>
                                            <div id="matric-error" class="my-2"></div>
                                            <footer style="font-size: 12px"><b>File Type:</b><font color="red"><i>.docx .doc .pptx .ppt .xlsx .xls .pdf .odt</i></font></footer>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-floating">
                                                <input type="text" class="form-control" name="topic" id="topic" placeholder="Topic" oninput="ProjectAdd()">
                                                <label for="name">Topic</label>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-floating">
                                                <select class="form-control" name="lecturer" id="lecturer" placeholder="Lecturer" oninput="ProjectAdd()">
                                                    <option value="">Select</option>
                                                    <?php 
                                                    $s = "SELECT * FROM lecturers where delete_flag = 0";
                                                    $q = mysqli_query($conn, $s);
                                                    while ($r = mysqli_fetch_array($q)) {
                                                        // code...
                                                    ?>
                                                    <option value="<?php echo $r['email']; ?>"><?php echo $r['fullname']; ?></option>
                                                    <?php 
                                                    }
                                                    ?>
                                                </select>
                                                <label for="lecturer">Lecturer</label>
                                            </div>
                                            <div id="email-error" class="my-2"></div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-floating">
                                                <select class="form-control" name="department" id="department" placeholder="Department" oninput="ProjectAdd()">
                                                    <option value="">Select</option>
                                                    <?php 
                                                    $s = "SELECT * FROM departments where delete_flag = 0";
                                                    $q = mysqli_query($conn, $s);
                                                    while ($r = mysqli_fetch_array($q)) {
                                                        // code...
                                                    ?>
                                                    <option value="<?php echo $r['dname']; ?>"><?php echo $r['dname']; ?></option>
                                                    <?php 
                                                    }
                                                    ?>
                                                </select>
                                                <label for="department">Department</label>
                                            </div>
                                            <div id="email-error" class="my-2"></div>
                                        </div>
                                        <div class="col-12 text-center">
                                            <button class="btn btn-danger w-50 py-2" type="submit" id="submit" name="submit"  disabled>submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <!-- Contact End -->



<div class="fixed-bottom">
<?php
include 'footer.php';
?>
</div>
  
</body>

</html>