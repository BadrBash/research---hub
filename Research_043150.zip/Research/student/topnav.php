  <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary"><i class="fa fa-book me-3"></i>RMS</h2>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.php" class="nav-item nav-link">Dashboard</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Projects <i class="fa fa-arrow-down"></i></a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="project-add.php" class="dropdown-item">Add New</a>
                        <a href="project.php" class="dropdown-item">Not Checked</a>
                        <a href="project-checked.php" class="dropdown-item">Checked</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Documents <i class="fa fa-arrow-down"></i></a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="notes.php" class="dropdown-item">Notes</a>
                    </div>
                </div>
                
            </div>
            <a href="#" id="slogout" class="btn btn-danger py-4 px-lg-3 d-none d-lg-block">
                Logout<i class="fa fa-arrow-left ms-3"></i></a>
        </div>
    </nav>
    <!-- Navbar End -->
