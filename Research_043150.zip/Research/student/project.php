<!DOCTYPE html>
<html lang="en">
<?php
include 'header.php';
?>
    
<body>

    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

<?php
include 'topnav.php';
?>

    <!-- Contact Start -->
    <div class="container-xxl pb-5 mt-5">
        <div class="container mb-5">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Student: <?php echo $matric; ?></h6>
            </div>
            <div class="mt-3">
                <div class="text-center">
                    <h5 class="">All Unchecked Projects</h5>
            </div>
        </div>
        <div class="d-flex align-items-center mb-5">
            <div class="container">
                <div class="row g-4 justify-content-center">
                        <div class="col-lg-12 col-md-12 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="card">
                            <div class="card-body shadow-sm">
                            <table id="example" class="table table-stripped" style="width:100%">
                                <thead>
                                  <tr>
                                  <th>#</th>
                                  <th>Matric No</th>
                                  <th>Topic</th>
                                  <th>Department</th>
                                  <th>Date</th>
                                  <th>Status</th>
                                  </tr>
                                </thead>

                                <?php
                                $sql = "SELECT * from `projects` where delete_flag = 0 and status = 1 and uploader = '$matric' order by id asc ";
                                $query = mysqli_query($conn, $sql);
                                $i = 1;
                                ?>
                                <tbody>
                                  <?php
                                    while($row = mysqli_fetch_array($query)) {
                                   ?>
                                   <tr id="<?php echo $row['id']; ?>">
                                    <!--<td><?php echo $i; ?></td>-->
                                    <td>
                                      <label class="switch switch-outline-alt-primary switch-pill form-control-label">
                                        <input type="checkbox" class="switch-input form-check-input"  id="category_check" name="category_id[]" value="<?php echo $row['id']; ?>">
                                        <span class="switch-label"></span>
                                        <span class="switch-handle"></span>
                                      </label>
                                    </td>
                                    <td><?php echo $row['uploader']; ?></td>
                                    <td><?php echo $row['topic']; ?></td>
                                    <td><?php echo $row['department']; ?></td>
                                    <td><?php echo $row['indate']; ?></td>
                                    <td>
                                      <?php 
                                      if ($row['status'] == 2) {
                                        echo '<span class="badge rounded-pill px-2 py-2 bg-success text-white">Checked</span>';
                                      } 
                                      if ($row['status'] == 1) {
                                        echo '<span class="badge rounded-pill px-2 py-2 bg-warning text-white">Pending</span>';
                                      } 
                                       ?>
                                    </td>
                                   </tr>
                                  <?php
                                    $i++;
                                  }
                                  ?>
                                </tbody>
                                <tfoot>
                                  <tr>
                                  <th>#</th>
                                  <th>Matric No</th>
                                  <th>Topic</th>
                                  <th>Department</th>
                                  <th>Date</th>
                                  <th>Status</th>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <!-- Contact End -->

<div class="modal fade" id="MakeComment">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Make Comment</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
              </button>
            </div>
            <form id="MakeComment">
              <div class="modal-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <input type="hidden" class="form-control rounded-0" id="id" name="id" readonly>
                      <div class="form-floating">
                            <textarea type="text" class="form-control" name="remark" id="remark" placeholder="Make Comment" oninput="MakeComment()"></textarea>
                            <label for="remark">Make Comment</label>
                        </div>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-dark btn-sm btn-pill" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger btn-sm btn-pill" id="submit" disabled>Submit</button>
              </div>
            </form>
          </div>
        </div>
      </div>

<div class="fixed-bottom">
<?php
include 'footer.php';
?>
</div>
  
</body>
<script>
    
// ======================================================================================
//  DELETE REGISTERED STUDENT Function
// ======================================================================================


  /*======== 34. VIEW RANGER DETAILS MODAL ========*/
$(document).delegate('[data-bs-target="#MakeComment"]', 'click', function () {
  var id = $(this).attr('data-id');
  $.ajax({
    url: '../process.php',
    type: 'POST',
    data: {id:id, ptype:'ProjectID'},
    success: function (response) {
    //once the request successfully process to the server side it will return result here
      response = JSON.parse(response);
      $("#MakeComment input").addClass('bg-transparent');
      $("#MakeComment textarea").addClass('bg-transparent');
      $("#MakeComment #id").val(response.id);
    } 
  })
})


</script>
</html>