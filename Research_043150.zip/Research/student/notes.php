<!DOCTYPE html>
<html lang="en">
<?php
include 'header.php';
?>
    
<body>

    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

<?php
include 'topnav.php';
?>

    <!-- Contact Start -->
    <div class="container-xxl pb-5 mt-5">
        <div class="container mb-5">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Student: <?php echo $matric; ?></h6>
            </div>
            <div class="mt-3">
                <div class="text-center">
                    <h5 class="">All Notes</h5>
            </div>
        </div>
        <div class="d-flex align-items-center mb-5">
            <div class="container">
                <div class="row g-4 justify-content-center">
                        <div class="col-lg-12 col-md-12 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="card">
                            <div class="card-body shadow-sm">
                            <table id="example" class="table table-stripped" style="width:100%">
                                <thead>
                                  <tr>
                                  <th>#</th>
                                  <th>Topic</th>
                                  <th>Level</th>
                                  <th>Department</th>
                                  <th>Indate</th>
                                  <th>Status</th>
                                  <th>Status</th>
                                  </tr>
                                </thead>

                                <?php
                                $sql = "SELECT * from `notes` where delete_flag = 0 order by id asc ";
                                $query = mysqli_query($conn, $sql);
                                $i = 1;
                                ?>
                                <tbody>
                                  <?php
                                    while($row = mysqli_fetch_array($query)) {
                                   ?>
                                   <tr id="<?php echo $row['id']; ?>">
                                    <!--<td><?php echo $i; ?></td>-->
                                    <td>
                                      <label class="switch switch-outline-alt-primary switch-pill form-control-label">
                                        <input type="checkbox" class="switch-input form-check-input"  id="category_check" name="category_id[]" value="<?php echo $row['id']; ?>">
                                        <span class="switch-label"></span>
                                        <span class="switch-handle"></span>
                                      </label>
                                    </td>
                                    <td><?php echo $row['topic']; ?></td>
                                    <td><?php echo $row['level']; ?></td>
                                    <td><?php echo $row['department']; ?></td>
                                    <td><?php echo $row['indate']; ?></td>
                                    <td>
                                      <?php 
                                      if ($row['status'] == 0) {
                                        echo '<span class="badge rounded-pill px-2 py-2 bg-danger text-white">Disabled</span>';
                                      } 
                                      if ($row['status'] == 1) {
                                        echo '<span class="badge rounded-pill px-2 py-2 bg-success text-white">Available</span>';
                                      } 
                                       ?>
                                    </td>
                                      
                                    <td>
                                      <a href='download.php?file_id=<?php echo $row['id']; ?>' type="button" data-id="<?php echo $row['id']; ?>"  class="btn btn-primary btn-sm px-2 py-1 btn-pill">Download</a>

                                    </td>
                                    
                                   </tr>
                                  <?php
                                    $i++;
                                  }
                                  ?>
                                </tbody>
                                <tfoot>
                                  <tr>
                                  <th>#</th>
                                  <th>Topic</th>
                                  <th>Level</th>
                                  <th>Department</th>
                                  <th>Indate</th>
                                  <th>Status</th>
                                  <th>Status</th>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <!-- Contact End -->



<div class="fixed-bottom">
<?php
include 'footer.php';
?>
</div>
  
</body>
<script>


</script>
</html>