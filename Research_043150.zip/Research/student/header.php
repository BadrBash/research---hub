<?php  
include "../conn.php";
 session_start();
    if (!$_SESSION["StudentLog"])
    {
        header('location:../alogin.php');
    }
        
$matric = $_SESSION['StudentLog'];

$sql_chk = "SELECT * FROM students WHERE matric = '$matric'";

$query_chk = mysqli_query($conn, $sql_chk);

$row_chk = mysqli_fetch_assoc($query_chk);

$userid = $row_chk['id'];
$fullname = $row_chk['fullname'];
$matric = $row_chk['matric'];
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>RMS - Students</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">
    <!-- Google Web Fonts -->

    <!-- Icon Font Stylesheet -->
    <link href="../assets/fontawesome-6.2.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../assets/lib/animate/animate.min.css" rel="stylesheet">
    <link href="../assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../assets/css/style.css" rel="stylesheet">
    
    <link href="../assets/sweetalert2/css/sweetalert2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/plugin/datatables/css/dataTables.bootstrap5.css">
</head>
