<!DOCTYPE html>
<html lang="en">
<?php
include 'header.php';
?>
    
<body>

    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

<?php
include 'topnav.php';
?>
  

    <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">Lecturer</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- Contact Start -->
    <div class="container-xxl pb-5">
        <div class="container mb-5">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Lecturer Login</h6>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <div class="container">
                <div class="row g-4 justify-content-center">
                    <div class="col-lg-5 col-md-12 wow fadeInUp" data-wow-delay="0.5s">
                        <form id="llogin">
                            <input type="hidden" name="ptype" value="LecturerLog" readonly>
                            <div class="row g-3">
                                <div class="col-md-125">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" name="email" id="email" placeholder="Your Email" oninput="llogin()">
                                        <label for="email">Your Email</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" oninput="llogin()">
                                        <label for="password">Password</label>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <button class="btn btn-danger w-50 py-3" type="button" id="submit" disabled>Login</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <!-- Contact End -->


    <div class="container-fluid bg-dark text-light footer pt-0 mt-5 wow fadeIn fixed-bottom" data-wow-delay="0.1s">
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="index.php">RMS</a>, All Right Reserved.
                        
                    </div>
                    <div class="col-md-3 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="index.php">Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- JavaScript Libraries -->
    <script src="assets/fontawesome-6.2.0/js/all.min.js"></script>
    <script src="assets/jquery/jquery-3.7.0.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/lib/wow/wow.min.js"></script>
    <script src="assets/lib/easing/easing.min.js"></script>
    <script src="assets/lib/waypoints/waypoints.min.js"></script>
    <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="assets/sweetalert2/js/sweetalert2.all.min.js"></script>

    <!-- Template Javascript -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>