<!DOCTYPE html>
<html lang="en">
<?php
include 'header.php';
?>
    
<body>

    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

<?php
include 'topnav.php';
?>

    <!-- Contact Start -->
    <div class="container-xxl pb-5 mt-5">
        <div class="container mb-5">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Admin: <?php echo $email; ?></h6>
            </div>
            <div class="mt-3">
                <div class="text-center">
                    <h5 class="">Add Department</h5>
                </div>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <div class="container">
                <div class="row g-4 justify-content-center">
                    <div class="col-lg-5 col-md-12 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="card mt-3">
                            <div class="card-body text-center shadow-sm">
                                <form id="DepartmentAdd">
                                    <input type="hidden" name="ptype" value="DepartmentAdd" readonly>
                                    <div class="row g-3">
                                        <div class="col-md-12">
                                            <div class="form-floating">
                                                <input type="text" class="form-control" name="dname" id="dname" placeholder="Department Name" oninput="DepartmentAdd()">
                                                <label for="dname">Department Name</label>
                                            </div>
                                            <div id="dname-error" class="my-2"></div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-floating">
                                                <input type="text" class="form-control" name="dshort" id="dshort" placeholder="Department Code" oninput="DepartmentAdd()">
                                                <label for="dshort">Department Short Name</label>
                                            </div>
                                            <div id="dshort-error" class="my-2"></div>
                                        </div>
                                        <div class="col-12 text-center">
                                            <button class="btn btn-danger w-50 py-2" type="button" id="submit" disabled>submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <!-- Contact End -->



<div class="fixed-bottom">
<?php
include 'footer.php';
?>
</div>
  
</body>

</html>