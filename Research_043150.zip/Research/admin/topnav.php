  <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary"><i class="fa fa-book me-3"></i>RMS</h2>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.php" class="nav-item nav-link">Dashboard</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Departments <i class="fa fa-arrow-down"></i></a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="department-add.php" class="dropdown-item">Add New</a>
                        <a href="department-manage.php" class="dropdown-item">Manage</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Students <i class="fa fa-arrow-down"></i></a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="student-add.php" class="dropdown-item">Add New</a>
                        <a href="student-manage.php" class="dropdown-item">Registered</a>
                        <a href="student-manage-un.php" class="dropdown-item">Unregistered</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Lecturers <i class="fa fa-arrow-down"></i></a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="lecturer-add.php" class="dropdown-item">Add New</a>
                        <a href="lecturer-manage.php" class="dropdown-item">Manage</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Documents <i class="fa fa-arrow-down"></i></a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="project-manage.php" class="dropdown-item">Projects</a>
                        <a href="notes-manage.php" class="dropdown-item">Notes</a>
                    </div>
                </div>
                
            </div>
            <a href="#" id="alogout" class="btn btn-danger py-4 px-lg-3 d-none d-lg-block">
                Logout<i class="fa fa-arrow-left ms-3"></i></a>
        </div>
    </nav>
    <!-- Navbar End -->
