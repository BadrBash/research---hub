<?php

$conn = mysqli_connect("localhost", "root", "", "research_db");

if (!$conn) {
	echo "Connection Failed!";
} 
?>