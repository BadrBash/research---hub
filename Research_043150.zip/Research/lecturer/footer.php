    <div class="container-fluid bg-dark text-light footer pt-0 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="index.php">RMS</a>, All Right Reserved.
                    </div>
                    <div class="col-md-3 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="index.php">Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="../assets/fontawesome-6.2.0/js/all.min.js"></script>
    <script src="../assets/jquery/jquery-3.7.0.min.js"></script>
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/lib/wow/wow.min.js"></script>
    <script src="../assets/lib/easing/easing.min.js"></script>
    <script src="../assets/lib/waypoints/waypoints.min.js"></script>
    <script src="../assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../assets/sweetalert2/js/sweetalert2.all.min.js"></script>

    <!-- Template Javascript -->
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/scripts.js"></script>
    <script src="../assets/plugin/datatables/js/jquery.dataTables.js"></script>
    <script src="../assets/plugin/datatables/js/dataTables.bootstrap5.js"></script>
    <script>
      $('#example').DataTable()
    </script>

